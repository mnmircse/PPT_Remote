"""PPT Remote - desktop app. Run: python server.py
Slide control + optional screen sharing / full touch control of this PC.
Phone must be on the same network. Every request needs the PIN."""
import os, sys, io, json, time, random, socket, threading, hmac, tkinter as tk
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import urlparse, parse_qs

if sys.platform == "win32":                      # real pixel coordinates on scaled displays
    try:
        import ctypes; ctypes.windll.shcore.SetProcessDpiAwareness(1)
    except Exception:
        pass

import pyautogui
pyautogui.FAILSAFE = False
pyautogui.PAUSE = 0

PORT = 8765
PIN = f"{random.randint(0, 999999):06d}"
SCREEN = threading.Event()          # set = screen sharing & full control allowed (OFF by default)
LOCK = threading.Lock()
ACTIVE = 0                          # number of live screen streams
MAX_STREAMS = 2
MAC = sys.platform == "darwin"
WIN = sys.platform == "win32"

# ---------------------------------------------------------------- actions
ACTIONS = {
    "next":   lambda: pyautogui.press("right"),
    "prev":   lambda: pyautogui.press("left"),
    "start":  lambda: pyautogui.press("f5"),
    "start_current": lambda: pyautogui.hotkey("shift", "f5"),
    "end":    lambda: pyautogui.press("esc"),
    "first":  lambda: pyautogui.press("home"),
    "last":   lambda: pyautogui.press("end"),
    "black":  lambda: pyautogui.press("b"),
    "white":  lambda: pyautogui.press("w"),
    "pointer": lambda: pyautogui.hotkey("ctrl", "l"),
}

KEYS = {  # whitelist for the on-screen special keys
    "enter": ["enter"], "backspace": ["backspace"], "tab": ["tab"], "esc": ["esc"],
    "up": ["up"], "down": ["down"], "left": ["left"], "right": ["right"],
    "delete": ["delete"], "home": ["home"], "end": ["end"],
    "pageup": ["pageup"], "pagedown": ["pagedown"], "space": ["space"],
    "win": ["win"], "alt+tab": ["alt", "tab"], "win+d": ["win", "d"],
    "ctrl+c": ["ctrl", "c"], "ctrl+v": ["ctrl", "v"], "ctrl+x": ["ctrl", "x"],
    "ctrl+z": ["ctrl", "z"], "ctrl+a": ["ctrl", "a"], "ctrl+s": ["ctrl", "s"],
}

def press_named(name):
    keys = list(KEYS[name])
    if MAC:
        keys = ["command", "tab"] if name == "alt+tab" else ["command" if k in ("ctrl", "win") else k for k in keys]
    pyautogui.hotkey(*keys) if len(keys) > 1 else pyautogui.press(keys[0])

def do_scroll(ticks):
    ticks = int(max(-40, min(40, ticks)))
    pyautogui.scroll(ticks * (60 if WIN else 2 if MAC else 1))

def pointer(d):
    act, btn = d.get("action"), d.get("button", "left")
    if btn not in ("left", "right", "middle"):
        btn = "left"
    if "x" in d and "y" in d:
        sw, sh = pyautogui.size()
        x = int(min(max(float(d["x"]), 0), 1) * (sw - 1))
        y = int(min(max(float(d["y"]), 0), 1) * (sh - 1))
        pyautogui.moveTo(x, y, _pause=False)
    if act == "down":   pyautogui.mouseDown(button=btn)
    elif act == "up":   pyautogui.mouseUp(button=btn)
    elif act == "click": pyautogui.click(button=btn)
    elif act == "scroll": do_scroll(d.get("ticks", 0))

# ---------------------------------------------------------------- PIN check with lockout
FAILS, GLOBAL_FAILS = {}, [0, 0.0]

def check_pin(ip, pin):
    now = time.time()
    with LOCK:
        cnt, until = FAILS.get(ip, (0, 0.0))
        if now < until or now < GLOBAL_FAILS[1]:
            return 429
        if hmac.compare_digest(str(pin or ""), PIN):
            FAILS.pop(ip, None); return 200
        cnt += 1
        if cnt >= 5:
            FAILS[ip] = (0, now + 300)                 # 5 wrong tries -> 5 min lockout for that device
        else:
            FAILS[ip] = (cnt, 0.0)
        GLOBAL_FAILS[0] += 1
        if GLOBAL_FAILS[0] >= 30:                      # many failures overall -> everyone waits 10 min
            GLOBAL_FAILS[:] = [0, now + 600]
        return 401

def local_ips():
    """All usable LAN IPs; works even with no internet (e.g. laptop hotspot)."""
    ips = []
    for target in ("10.255.255.255", "192.168.137.255", "8.8.8.8"):
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        try:
            s.connect((target, 1)); ips.append(s.getsockname()[0])
        except OSError:
            pass
        finally:
            s.close()
    try:
        for info in socket.getaddrinfo(socket.gethostname(), None, socket.AF_INET):
            ips.append(info[4][0])
    except OSError:
        pass
    out = []
    for ip in ips:
        if not ip.startswith(("127.", "169.254.", "0.")) and ip not in out:
            out.append(ip)
    return out or ["127.0.0.1"]

def base_dir():
    return getattr(sys, "_MEIPASS", os.path.dirname(os.path.abspath(__file__)))

# ---------------------------------------------------------------- HTTP
class Handler(BaseHTTPRequestHandler):
    def log_message(self, *a): pass

    def _send(self, code, body, ctype="application/json"):
        data = body.encode() if isinstance(body, str) else body
        self.send_response(code)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(data)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(data)

    def _auth(self, pin):
        code = check_pin(self.client_address[0], pin)
        if code == 401: self._send(401, '{"error":"wrong pin"}')
        if code == 429: self._send(429, '{"error":"locked"}')
        return code == 200

    def do_GET(self):
        u = urlparse(self.path)
        if u.path in ("/", "/index.html"):
            with open(os.path.join(base_dir(), "remote.html"), "rb") as f:
                return self._send(200, f.read(), "text/html; charset=utf-8")
        if u.path == "/screen.mjpg":
            q = parse_qs(u.query)
            if not self._auth(q.get("pin", [""])[0]): return
            if not SCREEN.is_set():
                return self._send(403, '{"error":"screen sharing is off"}')
            return self.stream(q)
        if u.path == "/manifest.webmanifest":
            m = {"name": "PPT Remote", "short_name": "PPT Remote", "start_url": "/", "display": "fullscreen",
                 "orientation": "landscape", "background_color": "#0d1020", "theme_color": "#0d1020",
                 "icons": [{"src": "/icon.png", "sizes": "1024x1024", "type": "image/png", "purpose": "any"}]}
            return self._send(200, json.dumps(m), "application/manifest+json")
        if u.path == "/icon.png":
            try:
                with open(os.path.join(base_dir(), "icon.png"), "rb") as f:
                    return self._send(200, f.read(), "image/png")
            except OSError:
                return self._send(404, "{}")
        self._send(404, "{}")

    def stream(self, q):
        global ACTIVE
        try:
            w = max(480, min(int(q.get("w", ["1280"])[0]), 2560))
            quality = max(20, min(int(q.get("q", ["55"])[0]), 85))
        except ValueError:
            w, quality = 1280, 55
        with LOCK:
            if ACTIVE >= MAX_STREAMS:
                return self._send(503, '{"error":"too many viewers"}')
            ACTIVE += 1
        try:
            import mss
            from PIL import Image, ImageDraw
            self.send_response(200)
            self.send_header("Content-Type", "multipart/x-mixed-replace; boundary=frame")
            self.send_header("Cache-Control", "no-store")
            self.end_headers()
            sw, sh = pyautogui.size()
            with mss.mss() as sct:
                mon = sct.monitors[1]                       # primary display
                while SCREEN.is_set():
                    t = time.time()
                    shot = sct.grab(mon)
                    im = Image.frombytes("RGB", shot.size, shot.bgra, "raw", "BGRX")
                    if im.width > w:
                        im = im.resize((w, int(im.height * w / im.width)), Image.BILINEAR)
                    try:                                    # draw the mouse cursor (not captured by default)
                        p = pyautogui.position()
                        cx, cy, k = p.x * im.width / sw, p.y * im.height / sh, max(1.0, im.width / 900)
                        pts = [(0, 0), (0, 17), (4, 13), (7, 20), (10, 19), (7, 12), (12, 12)]
                        ImageDraw.Draw(im).polygon([(cx + x * k, cy + y * k) for x, y in pts], fill="white", outline="black")
                    except Exception:
                        pass
                    buf = io.BytesIO(); im.save(buf, "JPEG", quality=quality)
                    data = buf.getvalue()
                    self.wfile.write(b"--frame\r\nContent-Type: image/jpeg\r\nContent-Length: %d\r\n\r\n" % len(data))
                    self.wfile.write(data); self.wfile.write(b"\r\n"); self.wfile.flush()
                    time.sleep(max(0.0, 1 / 15 - (time.time() - t)))
        except (BrokenPipeError, ConnectionResetError, ConnectionAbortedError, OSError):
            pass
        except Exception:
            pass
        finally:
            with LOCK:
                ACTIVE -= 1
            self.close_connection = True

    def do_POST(self):
        n = int(self.headers.get("Content-Length", 0))
        try:
            d = json.loads(self.rfile.read(n) or b"{}")
        except ValueError:
            return self._send(400, '{"error":"bad json"}')
        if not self._auth(d.get("pin")): return
        path = urlparse(self.path).path
        if path in ("/pointer", "/type", "/key") and not SCREEN.is_set():
            return self._send(403, '{"error":"screen sharing is off"}')
        try:
            if path == "/action" and d.get("name") in ACTIONS:
                ACTIONS[d["name"]]()
            elif path == "/move":
                pyautogui.moveRel(int(d.get("dx", 0)), int(d.get("dy", 0)), _pause=False)
            elif path == "/click":
                b = d.get("button", "left")
                pyautogui.click(button=b if b in ("left", "right") else "left")
            elif path == "/pointer":
                pointer(d)
            elif path == "/type":
                pyautogui.write(str(d.get("text", ""))[:200], interval=0)
            elif path == "/key" and d.get("name") in KEYS:
                press_named(d["name"])
            elif path != "/ping":
                return self._send(400, '{"error":"unknown"}')
        except Exception:
            return self._send(500, '{"error":"failed"}')
        self._send(200, '{"ok":true,"screen":%s}' % ("true" if SCREEN.is_set() else "false"))

# ---------------------------------------------------------------- desktop window
def main():
    srv = ThreadingHTTPServer(("0.0.0.0", PORT), Handler)
    threading.Thread(target=srv.serve_forever, daemon=True).start()
    ips = local_ips(); ip = ips[0]; url = f"http://{ip}:{PORT}/"

    root = tk.Tk(); root.title("PPT Remote"); root.resizable(False, False)
    try:
        from PIL import Image, ImageTk
        _ico = ImageTk.PhotoImage(Image.open(os.path.join(base_dir(), "icon.png")).resize((64, 64)))
        root.iconphoto(True, _ico); root._ico = _ico
    except Exception:
        pass
    tk.Label(root, text="PPT Remote is running", font=("Segoe UI", 14, "bold")).pack(padx=30, pady=(20, 5))
    tk.Label(root, text=f"Address:  {url}", font=("Segoe UI", 12)).pack()
    if len(ips) > 1:
        tk.Label(root, text="Other addresses: " + ", ".join(ips[1:]), fg="#555").pack()
    tk.Label(root, text=f"PIN:  {PIN}", font=("Segoe UI", 22, "bold")).pack(pady=8)
    try:
        import qrcode
        from PIL import ImageTk
        img = qrcode.make(f"{url}?pin={PIN}").resize((200, 200))
        photo = ImageTk.PhotoImage(img)
        lbl = tk.Label(root, image=photo); lbl.image = photo; lbl.pack(pady=5)
        tk.Label(root, text="Scan with phone camera or the app").pack()
    except Exception:
        pass

    box = tk.LabelFrame(root, text=" Screen sharing & full control ", padx=12, pady=8)
    box.pack(padx=20, pady=(14, 4), fill="x")
    var = tk.BooleanVar(value=False)
    def toggle():
        SCREEN.set() if var.get() else SCREEN.clear()
    tk.Checkbutton(box, text="Allow phone to see and control this PC", variable=var, command=toggle,
                   font=("Segoe UI", 10, "bold")).pack(anchor="w")
    status = tk.Label(box, text="Off", fg="#777"); status.pack(anchor="w")
    tk.Label(box, text="Only turn on at home or on a network you trust.\nAnyone with the PIN can use your PC while this is on.",
             fg="#b45309", justify="left").pack(anchor="w", pady=(4, 0))
    def refresh():
        if not var.get():            status.config(text="Off", fg="#777")
        elif ACTIVE > 0:             status.config(text="● Phone is viewing and controlling your screen", fg="#dc2626")
        else:                        status.config(text="On – waiting for phone", fg="#15803d")
        root.after(800, refresh)
    refresh()

    tk.Label(root, text="Open your slideshow, then control it from the phone.\nAllow Python through the firewall if asked.",
             fg="#555").pack(padx=20, pady=12)
    root.mainloop()

if __name__ == "__main__":
    main()
