@echo off
pip install -r requirements.txt pyinstaller
if not exist icon.ico python make_icon.py
pyinstaller --noconsole --onefile --icon icon.ico --collect-submodules mss --add-data "remote.html;." --add-data "icon.png;." --name PPTRemote server.py
echo.
echo Done: dist\PPTRemote.exe
pause
