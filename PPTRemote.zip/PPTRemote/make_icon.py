"""Generates icon.ico + icon.png (run once: python make_icon.py)"""
from PIL import Image, ImageDraw, ImageFilter

S = 1024
def lerp(a, b, t): return tuple(int(a[i] + (b[i] - a[i]) * t) for i in range(3))

# diagonal gradient blue -> violet
grad = Image.new("RGB", (S, S))
px = grad.load()
c1, c2 = (91, 124, 255), (138, 92, 255)
for y in range(S):
    for x in range(S):
        px[x, y] = lerp(c1, c2, (x + y) / (2 * S))

# soft light bloom top-left
bloom = Image.new("RGBA", (S, S), (0, 0, 0, 0))
ImageDraw.Draw(bloom).ellipse((-300, -400, 700, 500), fill=(255, 255, 255, 70))
bloom = bloom.filter(ImageFilter.GaussianBlur(120))
base = grad.convert("RGBA")
base.alpha_composite(bloom)

# rounded-square mask
mask = Image.new("L", (S, S), 0)
ImageDraw.Draw(mask).rounded_rectangle((0, 0, S - 1, S - 1), radius=230, fill=255)
icon = Image.new("RGBA", (S, S), (0, 0, 0, 0))
icon.paste(base, (0, 0), mask)

# slide screen (white card) with shadow
shadow = Image.new("RGBA", (S, S), (0, 0, 0, 0))
ImageDraw.Draw(shadow).rounded_rectangle((200, 270, 824, 690), radius=70, fill=(20, 15, 80, 120))
shadow = shadow.filter(ImageFilter.GaussianBlur(28)).transform((S, S), Image.AFFINE, (1, 0, 0, 0, 1, -24))
icon.alpha_composite(shadow)
d = ImageDraw.Draw(icon)
d.rounded_rectangle((200, 240, 824, 660), radius=70, fill=(255, 255, 255, 245))
# stand
d.rounded_rectangle((470, 660, 554, 740), radius=10, fill=(255, 255, 255, 235))
d.rounded_rectangle((385, 730, 639, 780), radius=25, fill=(255, 255, 255, 235))
# play triangle in gradient colour
d.polygon([(450, 350), (450, 550), (625, 450)], fill=(100, 108, 255, 255))
# little "pointer" dot, top-right of the screen
d.ellipse((706, 280, 766, 340), fill=(52, 211, 160, 255))

icon.save("icon.png")
icon.save("icon.ico", sizes=[(256, 256), (128, 128), (64, 64), (48, 48), (32, 32), (24, 24), (16, 16)])
print("icon.ico / icon.png created")
